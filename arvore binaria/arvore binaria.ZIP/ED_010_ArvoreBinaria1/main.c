#include <stdio.h>

struct no
{
    struct no *esquerda;
    int dado;
    struct no *direita;
};

struct no *inicio;
struct no *anterior;
struct no *aux;
char ultimo_movimento = ' ';

void adicionar(struct no *posicao, struct no *novo);
struct no *novo_no(int dado);
void inicializar();
void finalizar(struct no *posicao);
struct no *localizar(struct no *posicao, int dado);
void excluir(int dado);
void menu();

int opcao;
int numero;

int main()
{
    inicializar();

    while(opcao != 4)
    {
        menu();
        switch(opcao)
        {
            case 1:
                printf("Digite um numero: ");
                scanf("%d", &numero);
                adicionar(inicio, novo_no(numero));
                break;
            case 2:
                printf("Digite um numero: ");
                scanf("%d", &numero);
                excluir(numero);
                break;
            case 3:
                printf("Digite um numero: ");
                scanf("%d", &numero);
                aux = localizar(inicio, numero);
                if(aux == 0)
                    printf("Nao encontrei o dado!\n");
                else
                    printf("Encontrei %d!\n", aux->dado);
                break;
        }
    }

    finalizar(inicio);
}

void menu()
{
    printf("Menu\n");
    printf("1 - inserir\n");
    printf("2 - excluir\n");
    printf("3 - localizar\n");
    printf("4 - sair\n");

    printf("Digite sua opcao: ");
    scanf("%d", &opcao);
}

void inicializar()
{
    inicio = 0;
}

void adicionar(struct no *posicao, struct no *novo)
{

}

struct no *novo_no(int dado)
{
    struct no *novo;

    novo = malloc(sizeof(struct no));
    if(!novo)
    {
        printf("Nao consegui alocar memoria!\n");
        exit(-1);
    }
    novo->esquerda = 0;
    novo->dado = dado;
    novo->direita = 0;

    return novo;
}

void finalizar(struct no *posicao)
{

}

struct no *localizar(struct no *posicao, int dado)
{

}

void excluir(int dado)
{

}
